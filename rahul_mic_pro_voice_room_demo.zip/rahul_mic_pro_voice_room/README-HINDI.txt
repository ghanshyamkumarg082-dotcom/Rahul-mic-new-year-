RAHUL MIC PRO — LIVE VOICE ROOM STARTER

यह एक शुरुआती multi-person voice-room प्रोजेक्ट है।
यह केवल HTML फाइल नहीं है: इसे चलाने के लिए Node.js server और HTTPS hosting चाहिए।

चलाने के लिए:
1. कंप्यूटर/होस्टिंग पर Node.js 18 या नया संस्करण इंस्टॉल करें।
2. इस फोल्डर में terminal खोलें।
3. npm install चलाएँ।
4. npm start चलाएँ।
5. ब्राउज़र में https://your-domain/ खोलें (लोकल टेस्ट के लिए http://localhost:3000)।
6. दो या अधिक फोन/ब्राउज़र में एक ही Room Code डालकर Join करें।

महत्वपूर्ण:
- फोन पर माइक्रोफोन के लिए HTTPS जरूरी है (localhost अपवाद है)।
- यह demo WebRTC mesh का उपयोग करता है और अधिकतम 6 सदस्यों तक सीमित है।
- अलग-अलग नेटवर्क पर आवाज़ न जुड़े तो TURN server की जरूरत पड़ सकती है।
- असली बड़े/विश्वसनीय रूम के लिए LiveKit जैसे SFU सर्वर की सलाह है।
- सर्वर को सार्वजनिक इंटरनेट पर deploy किए बिना दूसरे लोग नहीं जुड़ पाएँगे।
- Room Code को निजी रखें। माइक केवल Join दबाने पर माँगा जाता है।
- यह starter production सुरक्षा, moderation, abuse reporting या authentication का विकल्प नहीं है।
