const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const MAX_PEOPLE_PER_ROOM = 6;

app.use(express.static("public"));

io.on("connection", (socket) => {
  socket.on("join-room", ({ roomCode, displayName } = {}) => {
    roomCode = String(roomCode || "").trim().toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 12);
    displayName = String(displayName || "Guest").trim().slice(0, 24) || "Guest";
    if (!roomCode) {
      socket.emit("room-error", "Room code डालें।");
      return;
    }

    const room = io.sockets.adapter.rooms.get(roomCode);
    if (room && room.size >= MAX_PEOPLE_PER_ROOM) {
      socket.emit("room-error", `इस demo room में अधिकतम ${MAX_PEOPLE_PER_ROOM} लोग जुड़ सकते हैं।`);
      return;
    }

    socket.data.roomCode = roomCode;
    socket.data.displayName = displayName;
    socket.join(roomCode);

    const peers = [];
    for (const id of (io.sockets.adapter.rooms.get(roomCode) || [])) {
      if (id !== socket.id) {
        const peerSocket = io.sockets.sockets.get(id);
        peers.push({ id, displayName: peerSocket?.data?.displayName || "Guest" });
      }
    }

    socket.emit("room-joined", {
      roomCode,
      selfId: socket.id,
      peers,
      maxPeople: MAX_PEOPLE_PER_ROOM
    });
    socket.to(roomCode).emit("user-joined", {
      id: socket.id,
      displayName
    });
  });

  socket.on("webrtc-signal", ({ to, signal } = {}) => {
    if (!to || !signal || !socket.data.roomCode) return;
    const target = io.sockets.sockets.get(to);
    if (!target || target.data.roomCode !== socket.data.roomCode) return;
    io.to(to).emit("webrtc-signal", {
      from: socket.id,
      displayName: socket.data.displayName || "Guest",
      signal
    });
  });

  socket.on("leave-room", () => leaveRoom(socket));
  socket.on("disconnect", () => leaveRoom(socket));
});

function leaveRoom(socket) {
  const roomCode = socket.data.roomCode;
  if (!roomCode) return;
  socket.to(roomCode).emit("user-left", { id: socket.id });
  socket.leave(roomCode);
  delete socket.data.roomCode;
}

server.listen(PORT, () => {
  console.log(`Rahul Mic Pro voice room running on port ${PORT}`);
});